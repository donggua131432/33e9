import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 回调
 * 
 * @author Administrator
 *
 */
@Controller
public class NotifyServerController {

	@RequestMapping(method = RequestMethod.POST, value = "/notifyServer/")
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Document doc = null;
		try {
			// 解析流
			InputStream in = request.getInputStream();
			BufferedReader bf = new BufferedReader(new InputStreamReader(in));
			String str = null;
			StringBuffer xmlfile = new StringBuffer();
			while ((str = bf.readLine()) != null) {
				xmlfile.append(str);
			}
			System.out.println(" --- xml body --- :" + xmlfile);
			doc = DocumentHelper.parseText(xmlfile.toString());
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		Element root = doc.getRootElement();
		String action = root.elementTextTrim("action");

		if (action.equals("CallInvite")) {
			// 呼叫发起通知
			parseCallInvite(root);
		} else if (action.equals("CallEstablish")) {
			// 呼叫建立通知
			parseCallEstablish(root);
		} else if (action.equals("Hangup")) {
			// 挂机通知
			parseHangup(root);
		} else if (action.equals("IncomeHangup")) {
			// 私密专线回呼挂机通知
			MaskNotify callNotify = new MaskNotify();
			callNotify.parseIncomeHangup(root);
		}
		String body = "<?xml version='1.0' encoding='UTF-8' ?><Response><statuscode>0000</statuscode><statusmsg>Success</statusmsg></Response>";
		// 设置返回header
		response.setHeader("Status-Code", "HTTP/1.1 200 OK");
		response.setHeader("Date", new Date() + "");
		response.setHeader("Content-Length", body.length() + "");
		try {
			// 输出 ，返回到客户端
			OutputStream opt = response.getOutputStream();
			OutputStreamWriter out = new OutputStreamWriter(opt);
			out.write(body);
			out.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 解析呼叫发起
	 * 
	 * @param e
	 *            Element
	 * @return result
	 */
	private void parseCallInvite(Element e) {
		String type = e.elementTextTrim("type");
		if ("1".equals(type)) {
			// 回拨呼叫发起
			CallBackNotify callNotify = new CallBackNotify();
			callNotify.parseCallInvite(e);
		} else if ("2".equals(type)) {
			// 私密专线呼叫发起
			MaskNotify maskCallNotify = new MaskNotify();
			maskCallNotify.parseMaskCallInvite(e);
		}
	}

	/**
	 * 解析呼叫建立
	 * 
	 * @param e
	 *            Element
	 * @return result
	 */
	private void parseCallEstablish(Element e) {
		String type = e.elementTextTrim("type");
		if ("1".equals(type)) {
			// 回拨呼叫建立
			CallBackNotify callNotify = new CallBackNotify();
			callNotify.parseCallEstablish(e);
		} else if ("2".equals(type)) {
			// 私密专线呼叫建立
			MaskNotify maskCallNotify = new MaskNotify();
			maskCallNotify.parseCallEstablish(e);

		}
	}

	/**
	 * 解析挂断请求
	 * 
	 * @param e
	 *            Element
	 * @return result
	 */
	private void parseHangup(Element e) {
		String type = e.elementTextTrim("type");
		if ("1".equals(type)) {
			// 回拨呼叫挂断
			CallBackNotify callNotify = new CallBackNotify();
			callNotify.parseHangup(e);
		} else if ("2".equals(type)) {
			// 私密专线呼叫挂断
			MaskNotify callNotify = new MaskNotify();
			callNotify.parseHangup(e);
		}
	}
}
