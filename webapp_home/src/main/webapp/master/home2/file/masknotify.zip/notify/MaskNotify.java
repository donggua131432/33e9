import org.dom4j.Element;

/**
 * 私密专线回调通知
 * 
 * @author Administrator
 *
 */
public class MaskNotify {
	/**
	 * 解析私密专线呼叫发起通知
	 * 
	 * @param e
	 */
	public void parseMaskCallInvite(Element e) {
		CallInvite call = new CallInvite();
		call.setType(e.elementTextTrim("type"));
		call.setAppId(e.elementTextTrim("appId"));
		call.setMaskNumber(e.elementTextTrim("maskNumber"));
		call.setCaller(e.elementTextTrim("caller"));
		call.setCalled(e.elementTextTrim("called"));
		call.setUserFlag(e.elementTextTrim("userFlag"));
		call.setCallId(e.elementTextTrim("callId"));
		call.setDateCreated(e.elementTextTrim("dateCreated"));
		call.setUserData(e.elementTextTrim("userData"));
	}

	/**
	 * 解析私密专线呼叫建立通知
	 * 
	 * @param e
	 *            Element
	 * @return result
	 */
	public void parseCallEstablish(Element e) {
		// 私密专线呼叫建立
		CallEstablish call = new CallEstablish();
		call.setType(e.elementTextTrim("type"));
		call.setAppId(e.elementTextTrim("appId"));
		call.setCaller(e.elementTextTrim("caller"));
		call.setCalled(e.elementTextTrim("called"));
		call.setMaskNumber(e.elementTextTrim("maskNumber"));
		call.setCallId(e.elementTextTrim("callId"));
		call.setDateCreated(e.elementTextTrim("dateCreated"));
	}

	/**
	 * 解析私密专线回呼挂断请求
	 * 
	 * @param e
	 *            Element
	 * @return result
	 */
	public void parseIncomeHangup(Element e) {
		// 私密专线回呼挂断
		CallIncomeHangup call = new CallIncomeHangup();
		call.setType(e.elementTextTrim("type"));
		call.setAppId(e.elementTextTrim("appId"));
		call.setMaskNumber(e.elementTextTrim("maskNumber"));
		call.setCaller(e.elementTextTrim("caller"));
		call.setCalled(e.elementTextTrim("called"));
		call.setStartTime(e.elementTextTrim("startTime"));
		call.setEndTime(e.elementTextTrim("endTime"));
		call.setDuration(e.elementTextTrim("duration"));
		call.setRecordUrl(e.elementTextTrim("recordUrl"));
		call.setByeType(e.elementTextTrim("byeType"));
		call.setDateCreated(e.elementTextTrim("dateCreated"));
	}

	/**
	 * 解析私密专线回拨挂断请求
	 * 
	 * @param e
	 *            Element
	 * @return result
	 */
	public void parseHangup(Element e) {
		CallHangup call = new CallHangup();
		call.setType(e.elementTextTrim("type"));
		call.setAppId(e.elementTextTrim("appId"));
		call.setMaskNumber(e.elementTextTrim("maskNumber"));
		call.setCaller(e.elementTextTrim("caller"));
		call.setCalled(e.elementTextTrim("called"));
		call.setStartTimeA(e.elementTextTrim("startTimeA"));
		call.setStartTimeB(e.elementTextTrim("startTimeB"));
		call.setEndTime(e.elementTextTrim("endTime"));
		call.setDuration(e.elementTextTrim("duration"));
		call.setCallId(e.elementTextTrim("callId"));
		call.setRecordUrl(e.elementTextTrim("recordUrl"));
		call.setByeType(e.elementTextTrim("byeType"));
		call.setDateCreated(e.elementTextTrim("dateCreated"));
		call.setUserData(e.elementTextTrim("userData"));
	}

	/**
	 * 呼叫发起通知接口(详见文档)
	 * 
	 * @author Administrator
	 *
	 */
	class CallInvite {
		// 呼叫类型1:专线语音,2:私密专线
		private String type;
		// 应用ID
		private String appId;
		// 主叫号码
		private String caller;
		// 被叫号码
		private String called;
		// 隐私号码
		private String maskNumber;
		// 主被叫标示(0标示主叫，1标示被叫)
		private String userFlag;
		// 呼叫的唯一标示
		private String callId;
		// 请求时间
		private String dateCreated;
		// 用户数据
		private String userData;

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getAppId() {
			return appId;
		}

		public void setAppId(String appId) {
			this.appId = appId;
		}

		public String getCaller() {
			return caller;
		}

		public void setCaller(String caller) {
			this.caller = caller;
		}

		public String getCalled() {
			return called;
		}

		public void setCalled(String called) {
			this.called = called;
		}

		public String getUserFlag() {
			return userFlag;
		}

		public void setUserFlag(String userFlag) {
			this.userFlag = userFlag;
		}

		public String getCallId() {
			return callId;
		}

		public void setCallId(String callId) {
			this.callId = callId;
		}

		public String getDateCreated() {
			return dateCreated;
		}

		public void setDateCreated(String dateCreated) {
			this.dateCreated = dateCreated;
		}

		public String getUserData() {
			return userData;
		}

		public void setUserData(String userData) {
			this.userData = userData;
		}

		public String getMaskNumber() {
			return maskNumber;
		}

		public void setMaskNumber(String maskNumber) {
			this.maskNumber = maskNumber;
		}

		@Override
		public String toString() {
			return "CallInvite [type=" + type + ", appId=" + appId + ", maskNumber=" + maskNumber + ", caller=" + caller
					+ ", called=" + called + ", userFlag=" + userFlag + ", callId=" + callId + ", dateCreated="
					+ dateCreated + ", userData=" + userData + "]";
		}

	}

	/**
	 * 
	 * 呼叫建立通知接口(详见文档)
	 * 
	 * @author Administrator
	 *
	 */

	static class CallEstablish {
		// 呼叫类型
		private String type;
		// 应用ID
		private String appId;
		// 主叫号码
		private String caller;
		// 被叫号码
		private String called;
		// 隐私号码
		private String maskNumber;
		// 呼叫的唯一标示
		private String callId;
		// 请求时间
		private String dateCreated;
		// 用户数据
		private String userData;

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getAppId() {
			return appId;
		}

		public void setAppId(String appId) {
			this.appId = appId;
		}

		public String getCaller() {
			return caller;
		}

		public void setCaller(String caller) {
			this.caller = caller;
		}

		public String getCalled() {
			return called;
		}

		public void setCalled(String called) {
			this.called = called;
		}

		public String getMaskNumber() {
			return maskNumber;
		}

		public void setMaskNumber(String maskNumber) {
			this.maskNumber = maskNumber;
		}

		public String getCallId() {
			return callId;
		}

		public void setCallId(String callId) {
			this.callId = callId;
		}

		public String getDateCreated() {
			return dateCreated;
		}

		public void setDateCreated(String dateCreated) {
			this.dateCreated = dateCreated;
		}

		public String getUserData() {
			return userData;
		}

		public void setUserData(String userData) {
			this.userData = userData;
		}

		@Override
		public String toString() {
			return "CallEstablish [type=" + type + ", appId=" + appId + ", maskNumber=" + maskNumber + ", caller="
					+ caller + ", called=" + called + ", callId=" + callId + ", dateCreated=" + dateCreated
					+ ", userData=" + userData + "]";
		}
	}

	/**
	 * 呼叫挂机通知
	 * 
	 * @author Administrator
	 *
	 */
	static class CallHangup {
		// 呼叫类型
		private String type;
		// 应用ID
		private String appId;
		// 主叫号码
		private String caller;
		// 被叫号码
		private String called;
		// 隐私号码
		private String maskNumber;
		// 回拨时，为主叫接听时间；
		private String startTimeA;
		// 回拨时，为被叫接听时间
		private String startTimeB;
		// 通话结束时间
		private String endTime;
		// 通话时长。
		private String duration;
		// 呼叫的唯一标示
		private String callId;
		// 录音地址
		private String recordUrl;
		// 通话挂机类型
		private String byeType;
		// 请求时间
		private String dateCreated;
		// 用户数据
		private String userData;

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getAppId() {
			return appId;
		}

		public void setAppId(String appId) {
			this.appId = appId;
		}

		public String getCaller() {
			return caller;
		}

		public void setCaller(String caller) {
			this.caller = caller;
		}

		public String getCalled() {
			return called;
		}

		public void setCalled(String called) {
			this.called = called;
		}

		public String getStartTimeA() {
			return startTimeA;
		}

		public void setStartTimeA(String startTimeA) {
			this.startTimeA = startTimeA;
		}

		public String getStartTimeB() {
			return startTimeB;
		}

		public void setStartTimeB(String startTimeB) {
			this.startTimeB = startTimeB;
		}

		public String getEndTime() {
			return endTime;
		}

		public void setEndTime(String endTime) {
			this.endTime = endTime;
		}

		public String getDuration() {
			return duration;
		}

		public void setDuration(String duration) {
			this.duration = duration;
		}

		public String getCallId() {
			return callId;
		}

		public void setCallId(String callId) {
			this.callId = callId;
		}

		public String getRecordUrl() {
			return recordUrl;
		}

		public void setRecordUrl(String recordUrl) {
			this.recordUrl = recordUrl;
		}

		public String getByeType() {
			return byeType;
		}

		public void setByeType(String byeType) {
			this.byeType = byeType;
		}

		public String getDateCreated() {
			return dateCreated;
		}

		public void setDateCreated(String dateCreated) {
			this.dateCreated = dateCreated;
		}

		public String getUserData() {
			return userData;
		}

		public void setUserData(String userData) {
			this.userData = userData;
		}

		public String getMaskNumber() {
			return maskNumber;
		}

		public void setMaskNumber(String maskNumber) {
			this.maskNumber = maskNumber;
		}

		@Override
		public String toString() {
			return "CallHangup [type=" + type + ", appId=" + appId + ", maskNumber=" + maskNumber + ", caller=" + caller
					+ ", called=" + called + ", startTimeA=" + startTimeA + ", startTimeB=" + startTimeB + ", endTime="
					+ endTime + ", duration=" + duration + ", callId=" + callId + ", recordUrl=" + recordUrl
					+ ", byeType=" + byeType + ", dateCreated=" + dateCreated + ", userData=" + userData + "]";
		}
	}

	/**
	 * 回呼挂机通知
	 * 
	 * @author Administrator
	 *
	 */
	static class CallIncomeHangup {
		// 呼叫类型
		private String type;
		// 应用ID
		private String appId;
		// 主叫号码
		private String caller;
		// 被叫号码
		private String called;
		// 隐私号码
		private String maskNumber;
		// 被叫接听时间
		private String startTime;
		// 通话结束时间
		private String endTime;
		// 通话时长。
		private String duration;
		// 录音地址
		private String recordUrl;
		// 通话挂机类型
		private String byeType;
		// 请求时间
		private String dateCreated;

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getAppId() {
			return appId;
		}

		public void setAppId(String appId) {
			this.appId = appId;
		}

		public String getCaller() {
			return caller;
		}

		public void setCaller(String caller) {
			this.caller = caller;
		}

		public String getCalled() {
			return called;
		}

		public void setCalled(String called) {
			this.called = called;
		}

		public String getStartTime() {
			return startTime;
		}

		public void setStartTime(String startTime) {
			this.startTime = startTime;
		}

		public String getEndTime() {
			return endTime;
		}

		public void setEndTime(String endTime) {
			this.endTime = endTime;
		}

		public String getDuration() {
			return duration;
		}

		public void setDuration(String duration) {
			this.duration = duration;
		}

		public String getRecordUrl() {
			return recordUrl;
		}

		public void setRecordUrl(String recordUrl) {
			this.recordUrl = recordUrl;
		}

		public String getByeType() {
			return byeType;
		}

		public void setByeType(String byeType) {
			this.byeType = byeType;
		}

		public String getDateCreated() {
			return dateCreated;
		}

		public void setDateCreated(String dateCreated) {
			this.dateCreated = dateCreated;
		}

		public String getMaskNumber() {
			return maskNumber;
		}

		public void setMaskNumber(String maskNumber) {
			this.maskNumber = maskNumber;
		}

		@Override
		public String toString() {
			return "CallHangup [type=" + type + ", appId=" + appId + ", maskNumber=" + maskNumber + ", caller=" + caller
					+ ", called=" + called + ", startTime=" + startTime + ", endTime=" + endTime + ", duration="
					+ duration + ", recordUrl=" + recordUrl + ", byeType=" + byeType + ", dateCreated=" + dateCreated
					+ "]";
		}
	}
}
