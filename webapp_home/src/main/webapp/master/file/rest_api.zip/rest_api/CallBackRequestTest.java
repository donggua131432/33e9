
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;

import com.e9cloud.openapi.RestApi;
import com.e9cloud.util.Util;

/**
 * 专线语音调用示例(详见文档)
 * 
 * @author Administrator
 *
 */
public class CallBackRequestTest {

	public static void main(String[] args) {
		// url地址
		String url = "api.33e9cloud.com";
		// 版本
		String version = "2016-01-01";
		// 账号id
		String accountSid = "";
		// 账号token
		String authToken = "";

		// 调用restapi初始化信息
		RestApi rest = new RestApi();
		rest.init(url);
		rest.setVersion(version);
		rest.setAccountInfo(accountSid, authToken);
		// 设置超时时间(可不设)
		// rest.setConnectTime(1);
		// callback(rest);
		cancelCallback(rest);
	}
	
		/**
	 * 专线语音
	 * 
	 * @param rest
	 */
	public static void callback(RestApi rest) {
		// 封装专线语音请求参数
		Map<String, Object> paramMap = new HashMap<String, Object>();
		// 应用id
		paramMap.put("appId", "");
		// 主叫
		paramMap.put("from", "");
		// 被叫
		paramMap.put("to", "");
		// 主叫显号
		List<String> fromSerNumList = new ArrayList<String>();
		fromSerNumList.add("");
		paramMap.put("fromSerNum", fromSerNumList);
		// 被叫显号
		List<String> toSerNumlist = new ArrayList<String>();
		toSerNumlist.add("");
		paramMap.put("toSerNum", toSerNumlist);
		// 是否需要录音
		paramMap.put("needRecord", 1);
		// 用户用户自定义数据(可不填)
		paramMap.put("userData", "");
		// 请求方式，是否json请求
		boolean isJson = true;
		// 请求专线语音
		HttpResponse response = rest.callback(isJson, paramMap);

		// 解析response
		try {
			System.out.println(Util.parseResponse(response, isJson));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 取消通话
	 * 
	 * @param rest
	 */
	public static void cancelCallback(RestApi rest) {
		// 应用id
		String appId = "";
		// 专线语音呼叫id
		String callId = "";
		// 请求方式，是否json请求
		boolean isJson = true;

		Map<String, Object> paramMap = new HashMap<String, Object>();
		// 应用id
		paramMap.put("appId", appId);
		// 专线语音呼叫id
		paramMap.put("callId", callId);
		// 请求取消通话
		HttpResponse response = rest.cancelCallback(isJson, paramMap);

		// 解析response
		try {
			System.out.println(Util.parseResponse(response, isJson));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}