import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import org.apache.http.*;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClients;

/**
 * 玖云平台录音文件下载事例
 */
public class DownloadRcdTest {

    /**
     * 根据实际运行效果 设置缓冲区大小
     */
    public static final int cache = 10 * 1024;

    /**
     * filePath自定义文件下载目录
     */
    public static final String filePath = "";

    /*下载成功*/
    public static final String authSuccess = "00";
    /*授权失败*/
    public static final String authFailure = "01";
    /*文件不存在*/
    public static final String authNotFound = "02";

    private static final String UTF8 = "utf-8";

    /**
     * 根据url下载文件，保存到filepath中
     * @param url
     * @param filepath
     * @return 00:下载成功 01：鉴权不通过 02:文件不存在
     */
    public static String download(String url, String filepath) throws Exception{
        try {
            HttpClient client = HttpClients.createDefault();
            HttpGet httpget = new HttpGet(url);
            HttpResponse response = client.execute(httpget);
            int statusCode = response.getStatusLine().getStatusCode();
            if (statusCode == HttpStatus.SC_OK) {
                HttpEntity entity = response.getEntity();
                InputStream is = entity.getContent();
                File file = new File(filepath);
                file.getParentFile().mkdirs();
                FileOutputStream fileout = new FileOutputStream(file);
                byte[] buffer = new byte[cache];
                int ch = 0;
                while ((ch = is.read(buffer)) != -1) {
                    fileout.write(buffer, 0, ch);
                }
                is.close();
                fileout.flush();
                fileout.close();
            } else if (statusCode == HttpStatus.SC_FORBIDDEN) {
                return authFailure;
            } else if (statusCode == HttpStatus.SC_NOT_FOUND) {
                return authNotFound;
            } else {
                return authFailure;
            }

        } catch (Exception e) {
             throw  new Exception("录音文件下载异常",e);
    }
        return authSuccess;
    }


    /**
     * 从url中获取文件名
     */
    public static String getFileNameFromUrl(String url) throws Exception {
        if(filePath==null||"".equals(filePath)){
            throw  new Exception("文件下载目录为空");
        }
        String name = "";
        int index = url.lastIndexOf("/");
        if (index > 0) {
            name = url.substring(index + 1);
            if (name.trim().length() > 0) {
                String recName[] = name.split("\\?");
                if (recName.length > 1 && recName[0].contains("mp3")) {
                    return filePath+recName[0];
                }
            }
        }
        return name;
    }

    /**
     *  录音下载地址规则生成
     *
     * @param recordUrl
     *            String 呼叫挂机计费通知接口recordUrl字段
     * @param accountSid
     *            String 主帐号Id 
     * @param authToken
     *            String 主帐号授权令牌 
     * @return
     */
    public static String genRcdUrl(String recordUrl,String accountSid ,String authToken) throws  Exception {
        if(recordUrl==null||"".equals(recordUrl)){
            throw  new Exception("录音下载url为空");
        }
        String sig = accountSid +":"+ authToken;
        String signature = "";
        try {
            //MD5数字签名
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] b = md.digest(sig.getBytes(UTF8));
            //字节数组转化为大写16进制字符串
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < b.length; i++) {
                String s = Integer.toHexString(b[i] & 0xFF);
                if (s.length() == 1) {
                    sb.append("0");
                }
                sb.append(s.toUpperCase());
            }
            signature = sb.toString();
        } catch (Exception e) {
            throw new Exception("获取签名失败！");
        }
        return recordUrl+="?auth="+signature;
    }

    public static void main(String[] args) {
		/*
		 * URL参数说明
		 * 请求示例 GET {downUrl}?auth={authParameter}
		 * URL后必须带有auth参数，例如：auth =AAABBBCCCDDDEEEFFFGGG • 使用MD5加密（主账号Id + : +
		 * 主账号授权令牌）；其中主账号Id和主账号授权令牌分别对应管理控制台中accountSid和authToken
		 */
        try {
            //呼叫挂机计费通知接口recordUrl字段
            String recordUrl = "http://d1.33e9cloud.com/xxxxxx/xxxxxx/xxxxxx.mp3";
            //主账号Id和主账号授权令牌分别对应管理控制台中accountSid和authToken
            String accountSid = "";
            String authToken = "";
            //生成录音下载鉴权地址
            String downloadUrl = genRcdUrl(recordUrl,accountSid,authToken);
            //从录音文件url中获取录音文件名称
            String filepath =  getFileNameFromUrl(downloadUrl);
            //根据url下载文件，保存到filepath中
            String result = DownloadRcdTest.download(downloadUrl, filepath);
            if (result.equals(authSuccess)) {
                System.out.println("下载成功");
            } else if (result.equals(authFailure)) {
                System.out.println("下载失败，鉴权不通过");
            } else if (result.equals(authNotFound)) {
                //文件不存在原因:文件已过期（超过30天）
                System.out.println("下载失败，文件不存在");
            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }
}