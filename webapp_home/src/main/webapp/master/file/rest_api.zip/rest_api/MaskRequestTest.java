
import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpResponse;

import com.e9cloud.openapi.RestApi;
import com.e9cloud.util.Util;

/**
 * 专号通调用示例(详见文档)
 * 
 * @author Administrator
 *
 */
public class MaskRequestTest {

	public static void main(String[] args) {
		// url地址
		String url = "api.33e9cloud.com";
		// 版本
		String version = "2016-01-01";
		// 账号id
		String accountSid = "";
		// 账号token
		String authToken = "";

		// 调用restapi初始化信息
		RestApi rest = new RestApi();
		rest.init(url);
		rest.setVersion(version);
		rest.setAccountInfo(accountSid, authToken);
		// 设置超时时间(可不设)
		// rest.setConnectTime(1);

		applyMaskNum(rest);
		// queryMaskNum(rest);
		// releaseMaskNum(rest);
		// queryAll(rest);
		// maskCall(rest);
	}

	/**
	 * 申请隐私号
	 * 
	 * @param rest
	 */
	public static void applyMaskNum(RestApi rest) {
		// 封装申请隐私号请求参数
		Map<String, Object> paramMap = new HashMap<String, Object>();
		// 应用id
		paramMap.put("appId", "");
		// 真实号码1
		paramMap.put("realNumA", "");
		// 真实号码2
		paramMap.put("realNumB", "");

		// 是否需要录音(0表示不录音；1表示录音,可不填默认值0不录音)
		paramMap.put("needRecord", 1);
		// 隐私号码有效时间，秒为单位(可不填,例如3600秒-有效时间为一个小时，不传默认24小时有效)
		paramMap.put("validTime", 3600);
		// 传入区号，根据区号选择对应地区的可用隐私号码，不传则隐私号码池全局选择隐私号码(可不填)
		paramMap.put("areaCode", "");

		// 请求方式，是否json请求
		boolean isJson = true;
		// 回拨
		HttpResponse response = rest.maskNumApply(isJson, paramMap);

		// 解析response
		try {
			System.out.println(Util.parseResponse(response, isJson));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 查询映射隐私号码
	 * 
	 * @param rest
	 */
	public static void queryMaskNum(RestApi rest) {
		// 应用id
		String appId = "";
		// 申请隐私号码的真实号码1，1、2两个号码的顺序可互换
		String realNumA = "";
		// 申请隐私号码的真实号码2，1、2两个号码的顺序可互换
		String realNumB = "";

		// 请求方式，是否json请求
		boolean isJson = true;
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("appId", appId);
		paramMap.put("realNumA", realNumA);
		paramMap.put("realNumB", realNumB);
		// 回拨
		HttpResponse response = rest.maskNumQuery(isJson, paramMap);

		// 解析response
		try {
			System.out.println(Util.parseResponse(response, isJson));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 释放隐私号
	 * 
	 * @param rest
	 */
	public static void releaseMaskNum(RestApi rest) {
		// 应用id
		String appId = "";
		// 申请隐私号码的真实号码1，1、2两个号码的顺序可互换
		String realNumA = "";
		// 申请隐私号码的真实号码2，1、2两个号码的顺序可互换
		String realNumB = "";
		// 请求方式，是否json请求
		boolean isJson = true;
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("appId", appId);
		paramMap.put("realNumA", realNumA);
		paramMap.put("realNumB", realNumB);
		// 释放隐私号
		HttpResponse response = rest.maskNumRelease(isJson, paramMap);

		// 解析response
		try {
			System.out.println(Util.parseResponse(response, isJson));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 专号通回拨
	 * 
	 * @param rest
	 */
	public static void maskCall(RestApi rest) {
		// 应用id
		String appId = "";
		// 主叫电话号码。目前支持手机及固定电话
		String from = "";
		// 被叫电话号码。目前支持手机及固定电话
		String to = "";
		// 隐私号码为主被叫号码对应的平台动态分配的号码，用于显号。若映射不存在或不正确不能发起呼叫
		String maskNum = "";
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("appId", appId);
		paramMap.put("from", from);
		paramMap.put("to", to);
		paramMap.put("maskNumber", maskNum);

		// 可选参数
		// 是否录音：0表示不录音；1表示录音；默认值0
		paramMap.put("needRecord", 1);
		// 用户自定义数据，最长可支持128字节。如用户配置了回调接口，则在回调接口中将这一数据原样返回
		paramMap.put("userData", "");
		// 通话的最大时长,单位为秒。当通话时长到达最大时长则挂断通话。默认值空。开发者设置的最大通话时长最长为8小时，超过8小时返回错误码。计时以主被叫建立通话为起始
		paramMap.put("maxCallTime", 3600);

		// 回拨
		// 请求方式，是否json请求
		boolean isJson = true;
		HttpResponse response = rest.maskCallback(isJson, paramMap);

		// 解析response
		try {
			System.out.println(Util.parseResponse(response, isJson));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 查询应用下映射隐私号码
	 * 
	 * @param rest
	 */
	public static void queryAll(RestApi rest) {
		// 应用id
		String appId = "";

		// 请求方式，是否json请求
		boolean isJson = true;
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("appId", appId);
		// 可选参数,设置查询区号
		paramMap.put("areaCode", "");

		// 查询应用全部映射隐私号码
		HttpResponse response = rest.maskNumQueryAll(isJson, paramMap);

		// 解析response
		try {
			System.out.println(Util.parseResponse(response, isJson));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}